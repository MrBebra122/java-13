package com.example.a2pract;


import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView profileIv; // Объект для отображения изображения профиля
    Button cameraBtn, galleryBtn; // Кнопки для камеры и галереи

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        profileIv = findViewById(R.id.profile_iv);
        cameraBtn = findViewById(R.id.camera_btn); // кнопки для камеры
        galleryBtn = findViewById(R.id.gallary_btn); // кнопки для галереи

        // Установка слушателя для кнопки камеры
        cameraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); // Создание намерения для запуска камеры
                cameraResultLauncher.launch(cameraIntent); // Запуск камеры
            }
        });
    }

    // Регистрация обработчика результата для запуска активности
    ActivityResultLauncher<Intent> cameraResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), // Контракт для получения результата
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) { // Метод, вызываемый при получении результата
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bitmap avatar = (Bitmap) result.getData().getExtras().get("data");
                        profileIv.setImageBitmap(avatar); // Установка изображения в ImageView
                    }
                }
            });
}